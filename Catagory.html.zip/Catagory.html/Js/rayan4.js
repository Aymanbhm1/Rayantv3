
 function startLeftAnimation(element) {
            const textParagraph = element.querySelector("p");
            textParagraph.classList.add("move-left");
        }